//
//  MasterViewController.m
//  iovSample
//
//  Created by David E. Wheeler on 10/1/14.
//  Copyright (c) 2014 iovation, Inc. All rights reserved.
//

#import "MasterViewController.h"

@interface MasterViewController ()

@end

@implementation MasterViewController

// See SampleUIKitViewController.m for the native UIKit integration.
// See SampleUIWebViewController.m for the hybird UIWebView integration.
// See SampleWebKitViewController.swift for the hybird WebKit integration.

@end
