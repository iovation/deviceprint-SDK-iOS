//
//  AppDelegate.h
//  iovSample
//
//  Created by Greg Crow on 9/11/13.
//  Copyright (c) 2013 iovation, Inc. All rights reserved.
//

@import UIKit;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
