//
//  iovSampleTests.m
//  iovSampleTests
//
//  Created by Greg Crow on 9/11/13.
//  Copyright (c) 2013 iovation, Inc. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface iovSampleTests : XCTestCase

@end

@implementation iovSampleTests

- (void)testExample
{
    XCTAssertTrue(YES, @"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
