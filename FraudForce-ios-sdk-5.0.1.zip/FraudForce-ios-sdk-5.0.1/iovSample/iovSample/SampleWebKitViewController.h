//
//  SampleWebKitViewController.h
//  iovSample
//
//  Created by David E. Wheeler on 9/8/15.
//  Copyright © 2015 iovation, Inc. All rights reserved.
//

@import UIKit;
@import WebKit;

@interface SampleWebKitViewController : UIViewController <WKScriptMessageHandler>

@end
